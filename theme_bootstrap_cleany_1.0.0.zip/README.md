# theme_bootstrap_cleany
TYPO3 compatible adaptation of the "Cleany - HTML5 Landing Page" by simplesphere

# Lincense
Extended Wrap Bootstrap license for this theme has been bought by Cybercraft Media Manufactory, Clausthal-Zellerfeld, Germany.
The extension is redistributed under MIT license and can be freely used and modified according to the terms defined in the LICENSE file.
